from typing import List

def calculate_positive_sum(numbers: List[int]) -> int:
    """
    Calculates the sum of all positive numbers in a given list.

    :param numbers: A list of integers.
    :return: The sum of all positive numbers in the list.
    """
    return sum(number for number in numbers if number > 0)