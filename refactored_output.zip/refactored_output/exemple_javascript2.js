function calculateShippingCost(user, order) {
    if (!user || !user.isActive) {
        return user ? 0 : null; // Return 0 for inactive users or null for non-existent users
    }

    if (order.items.length === 0) {
        throw new Error("Order is empty");
    }

    const destination = order.destination;
    const isExpress = order.isExpress;

    let baseCost = destination === "FR" ? (isExpress ? 15 : 5) : 25; // International

    return baseCost;
}