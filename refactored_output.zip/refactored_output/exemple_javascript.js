import axios from 'axios';

async function getUserData(id) {
    try {
        const response = await axios.get(`/api/users/${id}`);
        return response.data;
    } catch (error) {
        throw new Error(`Error: ${error.response ? error.response.status : error.message}`);
    }
}